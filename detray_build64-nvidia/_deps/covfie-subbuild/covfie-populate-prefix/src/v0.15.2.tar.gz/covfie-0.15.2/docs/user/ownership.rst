Data ownership
==============
