C++20 concepts
==============
