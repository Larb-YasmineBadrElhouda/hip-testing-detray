# Layers as GADTs

This is a super simple example that shows the way computation is modelled in
covfie, as composable layers. The Haskell formulation is somewhat more elegant
than what we can do in C++, but such is life.
