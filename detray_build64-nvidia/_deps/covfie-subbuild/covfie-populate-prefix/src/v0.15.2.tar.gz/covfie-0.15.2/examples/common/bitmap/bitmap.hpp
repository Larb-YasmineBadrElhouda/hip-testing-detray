/*
 * SPDX-PackageName: "covfie, a part of the ACTS project"
 * SPDX-FileCopyrightText: 2022 CERN
 * SPDX-License-Identifier: MPL-2.0
 */

#pragma once

#include <string>

void render_bitmap(
    unsigned char * img, unsigned int w, unsigned int h, std::string fname
);
