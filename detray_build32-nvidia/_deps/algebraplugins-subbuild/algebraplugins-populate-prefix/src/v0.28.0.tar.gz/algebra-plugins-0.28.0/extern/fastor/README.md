# Build Recipe for Fastor

This directory holds a simple build recipe for the
[Fastor](https://github.com/romeric/Fastor) project.
