# Vc Build Instructions

This directory holds a simple build recipe for the
[Vc](https://github.com/VcDevel/Vc/) project.
