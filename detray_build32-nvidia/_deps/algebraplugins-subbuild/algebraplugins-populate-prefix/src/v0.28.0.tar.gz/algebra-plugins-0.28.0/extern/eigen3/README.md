# Build Recipe for Eigen3

This directory holds a simple build recipe for the
[Eigen3](https://eigen.tuxfamily.org) project.
